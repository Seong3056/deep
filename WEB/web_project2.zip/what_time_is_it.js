function whatTimeIsIt() {
    alert(new Date());               
}