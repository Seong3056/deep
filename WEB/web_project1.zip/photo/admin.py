from django.contrib import admin
from.models import Photo

# Register your models here.
admin.site.register(Photo) # photo모델을 어드민 페이지에 등록